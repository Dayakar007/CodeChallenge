﻿using OrderProcessSystem.Models;
using AutoFixture;

namespace OrderProcessSystem.Helpers
{
    public static class ObjectPackagingSlip
    {
        public static PackagingSlip GetPackagingSlip()
        {
            return new Fixture().Create<PackagingSlip>();
        }

        public static RoyaltyPackagingSlip GetRoyaltyPackagingSlip()
        {
            return new Fixture().Create<RoyaltyPackagingSlip>();
        }
    }
}
