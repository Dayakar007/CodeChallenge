﻿using OrderProcessSystem.Models;
using System;

namespace OrderProcessSystem.PaymentServices
{
    public class MembershipPaymentService : IPaymentService
    {
        public bool ProcessPayment(PaymentType paymentType)
        {
            ActivateMemberShip();
            if (paymentType == PaymentType.MembershipUpgrade)
                UpgradeMemberShip();
            Console.WriteLine("An email has been sent to owner regarding Subscription/Upgradation.");
            return true;
        }

        public void ActivateMemberShip()
        {
            Console.WriteLine("***************************************************\n Membership Activation");
            Console.WriteLine("Your membership has been activated.");
        }

        public void UpgradeMemberShip()
        {
            Console.WriteLine("***************************************************\nMembership Upgration");
            Console.WriteLine("Your membership has been upgraded.");
        }
    }
}
