﻿using OrderProcessSystem.Models;

namespace OrderProcessSystem.PaymentServices
{
    public interface IPaymentService
    {
        bool ProcessPayment(PaymentType paymentType);
    }
}
