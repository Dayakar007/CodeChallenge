﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrderProcessSystem.Models
{
    public class RoyaltyPackagingSlip
    {
        public string RoyaltyCompanyName { get; set; }
        public string RoyaltyCompanyAddress { get; set; }
    }
}
